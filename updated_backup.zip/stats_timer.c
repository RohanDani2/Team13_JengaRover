#include <stats_timer.h>

int sTimerFunct()
{
    Timer_Handle timer1;
    Timer_Params params;

    Timer_init();

    Timer_Params_init(&params);
    params.period = 5000000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = sTimerCallback;

    timer1 = Timer_open(CONFIG_TIMER_1, &params);
    if (timer1 == NULL || Timer_start(timer1) == Timer_STATUS_ERROR){
        return 0;
    }
    return 1;
}

// when timer expires, queue event to indicate that a statistics msg should be published
void sTimerCallback(Timer_Handle stHandle)
{
    dbgOutputLoc(DLOC_ENTER_ISR);
    struct pubSubMsg m;

    m.type = PUBLISH_STAT_TYPE;

    dbgOutputLoc(DLOC_BEFORE_ISR_QUEUE);
    //write message indicating timer expired event
    if(!sendMsgToPSQueue(&m)){
        //dbgFail();
    }
    dbgOutputLoc(DLOC_AFTER_ISR_QUEUE);
    dbgOutputLoc(DLOC_LEAVE_ISR);
}
