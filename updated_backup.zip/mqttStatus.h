#ifndef MQTTSTATUS_H_
#define MQTTSTATUS_H_

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#define CLIENT_ID_LEN 13

struct mqttClientState{
    int32_t gApConnectionState;
    uint32_t gInitState;
    bool gResetApplication;
    uint32_t gUiConnFlag;
    char ClientId[CLIENT_ID_LEN];
};

// initialize what were globals in mqtt_client_app.c
void initializeState();

// getters and setters for struct
int32_t getApConnectionState();
void updateConnectionState(int32_t newConnectionState);
uint32_t getInitState();
void updateInitState(uint32_t newInitState);
bool getResetApplication();
void updateResetApplication(bool newResetApplication);
uint32_t getUiConnFlag();
void updateUiConnFlag(uint32_t newUiConnFlag);
char * getClientId();
void updateClientId(char * newClientId);

#endif /* MQTTSTATUS_H_ */
