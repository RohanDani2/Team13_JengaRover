#include <publish_timer.h>

int pTimerFunct()
{
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();

    Timer_Params_init(&params);
    params.period = 100000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = pTimerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL || Timer_start(timer0) == Timer_STATUS_ERROR){
        return 0;
    }
    return 1;
};

// when timer expires, queue event to indicate that a message should be published
void pTimerCallback(Timer_Handle ptHandle)
{
    dbgOutputLoc(DLOC_ENTER_ISR);
    int32_t i;
    struct pubSubMsg m;

    m.type = PUBLISH_DATA_TYPE;

    char testString[SENSOR_VAL_LEN];

    // generate simulated sensor data by creating random integer string
    for(i = 0; i < SENSOR_VAL_LEN; i++){
        testString[i] = (rand() % 10) + '0';
    }

    int n = snprintf(m.data_buf, MAX_MSG_BUF_SIZE, "%s", testString);

    if(n >= 0 && n < MAX_MSG_BUF_SIZE){
        //write message indicating timer expired event
        dbgOutputLoc(DLOC_BEFORE_ISR_QUEUE);
        if(!sendMsgToPSQueue(&m)){
            //dbgFail();
        }
        dbgOutputLoc(DLOC_AFTER_ISR_QUEUE);
    }
    dbgOutputLoc(DLOC_LEAVE_ISR);
};
