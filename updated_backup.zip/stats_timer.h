#ifndef STATS_TIMER_H_
#define STATS_TIMER_H_

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Driver Header files */
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#include <debug.h>
#include <uart_term.h>
#include <pubSubQueue.h>

int sTimerFunct();
void sTimerCallback(Timer_Handle stHandle);

#endif /* STATS_TIMER_H_ */
