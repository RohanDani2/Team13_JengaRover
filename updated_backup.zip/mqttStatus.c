#include <mqttStatus.h>

static struct mqttClientState s;

void initializeState(){
    s.gApConnectionState = -1;
    s.gInitState = 0;
    s.gResetApplication = false;
    s.gUiConnFlag = 0;

    char temp[CLIENT_ID_LEN] = {'\0'};
    snprintf(s.ClientId, CLIENT_ID_LEN, "%s", temp);
};

int32_t getApConnectionState(){
    return s.gApConnectionState;
};

void updateConnectionState(int32_t newConnectionState){
    s.gApConnectionState = newConnectionState;
};

uint32_t getInitState(){
    return s.gInitState;
};

void updateInitState(uint32_t newInitState){
    s.gInitState = newInitState;
};

bool getResetApplication(){
    return s.gResetApplication;
};

void updateResetApplication(bool newResetApplication){
    s.gResetApplication = newResetApplication;
};

uint32_t getUiConnFlag(){
    return s.gUiConnFlag;
};

void updateUiConnFlag(uint32_t newUiConnFlag){
    s.gUiConnFlag = newUiConnFlag;
};

char * getClientId(){
    return s.ClientId;
};

void updateClientId(char * newClientId){ // assumes safe usage
    snprintf(s.ClientId, CLIENT_ID_LEN, "%s", newClientId);
};
