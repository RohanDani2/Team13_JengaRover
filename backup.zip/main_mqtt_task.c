#include <main_mqtt_task.h>

void *mainMqttTask(void *arg0){
    dbgOutputLoc(DLOC_TASK_ENTER);
    struct pubSubMsg m;
    struct recvMsg r;
    int32_t sequence = 0, state1 = -1, state2 = -1;

    char publish_topic0[MAX_TOPIC_LEN] = { PUBLISH_TOPIC0 };
    char publish_topic1[MAX_TOPIC_LEN] = { PUBLISH_TOPIC1 };
    char publish_data[MAX_MSG_BUF_SIZE];

    dbgOutputLoc(DLOC_BEFORE_WHILE);
    while(1){
        dbgOutputLoc(DLOC_BEFORE_QUEUE);
        if(readFromPSQueue(&m) && getInitState() == 0){
            dbgOutputLoc(DLOC_AFTER_QUEUE);
            if(m.type == PUBLISH_DATA_TYPE){
                if(jsonifySensor(publish_data, MAX_MSG_BUF_SIZE, m.data_buf, sequence) &&sendMQTTJSON(publish_topic0, publish_data)){
                    sequence++;
                    updatePublishAttempt();
                    UART_PRINT("Published sensor message\n\r");
                }else{
                    UART_PRINT("Failed to send sensor message\n\r\n\r");
                }
            }else if(m.type == PUBLISH_STAT_TYPE){
                if(jsonifyStats(publish_data, MAX_MSG_BUF_SIZE, getPublishAttempt(), getSubscribeReceived(), getSubscribeShouldReceived())
                        && sendMQTTJSON(publish_topic1, publish_data)){
                    UART_PRINT("Published stats message\n\r");
                }else{
                    UART_PRINT("Failed to send stats msg\n\r\n\r");
                }
            }else if(m.type == SUBSCRIBE_TYPE){
                // receive topic0 message
                if(strncmp(m.topic, SUBSCRIPTION_TOPIC0, SUB_TOPIC0_LEN) == 0){
                    if(parseStateJSON(m.data_buf, &r)){
                        updateSubscribeReceied();
                        updateSubscribeShouldReceivedState1(r.seq);
                    }else{
                        UART_PRINT("Failed to parse state message: \n\r %s\n\r", m.data_buf);
                    }
                }
                else {
                    UART_PRINT("Error: Unknown subscribe topic: %s\n\r\n\r", m.topic);
                    dbgFail();
                }
            }else{
                UART_PRINT("Error: Unknown queue message\n\r\n\r");
                dbgFail();
            }
        }
    }
};

