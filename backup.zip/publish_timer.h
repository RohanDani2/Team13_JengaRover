#ifndef PUBLISH_TIMER_H_
#define PUBLISH_TIMER_H_

#include <stdio.h>
#include <string.h>
#include <stdint.h>

/* Driver Header files */
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#include <debug.h>
#include <uart_term.h>
#include <pubSubQueue.h>

int pTimerFunct();
void pTimerCallback(Timer_Handle ptHandle);

#endif /* PUBLISH_TIMER_H_ */
