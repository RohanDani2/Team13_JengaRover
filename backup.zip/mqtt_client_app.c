#include <mqtt_client_app.h>

//static global to mqtt client instance
static MQTTClient_Handle gMqttClient;

// start external main thread
int startMainMQTTTask(){
    return xTaskCreate( mainMqttTask, "main mqtt",configPOSIX_STACK_SIZE*4, NULL,SPAWN_TASK_PRIORITY, NULL) == pdPASS;
}

int createMotorThread() {
    return xTaskCreate( motorThread, "main motor",configPOSIX_STACK_SIZE*4, NULL,SPAWN_TASK_PRIORITY, NULL) == pdPASS;
}

//*****************************************************************************
//
//! MQTT_SendMsgToQueue - push queueElement to queue
//!
//! \param[in] struct message *queueElement
//!
//! \return 0 on success, -1 on error
//
//*****************************************************************************
int32_t MQTT_SendMsgToQueue(struct eventMessage *queueElement){
    if(sendMsgToEventQueue(queueElement)){
        return(0);
    }
    return(-1);
}

void * MqttClientThread(void * pvParameters)
{
    dbgOutputLoc(DLOC_TASK_ENTER);
    struct eventMessage queueElement;
    struct eventMessage queueElemRecv;

    MQTTClient_run((MQTTClient_Handle)pvParameters);

    queueElement.event = LOCAL_CLIENT_DISCONNECTION;
    queueElement.msgPtr = NULL;

    /*write message indicating disconnect Broker message.                   */
    if(MQTT_SendMsgToQueue(&queueElement))
    {
        UART_PRINT(
            "\n\n\rQueue is full, throw first msg and send the new one\n\n\r");
        if(readFromEventQueue(&queueElemRecv)){
            MQTT_SendMsgToQueue(&queueElement);
        }else{
            UART_PRINT("\n\n\rError throwing first msg in queue.\n\n\r");
            dbgFail();
        }
    }

    vTaskSuspend(NULL);
};

//*****************************************************************************
// attempt to send JSON formatted message over mqtt
// return 1 on success and 0 on failure
//*****************************************************************************
int sendMQTTJSON(char* publish_topic, char* publish_data){

    //send publish message
    int ret = MQTTClient_publish(gMqttClient, (char*) publish_topic, strlen(
                              (char*)publish_topic),
                          (char*)publish_data,
                          strlen((char*) publish_data), MQTT_QOS_2 |
                          ((RETAIN_ENABLE) ? MQTT_PUBLISH_RETAIN : 0));
    return ret == 0;
};

//*****************************************************************************
//
//! Task implementing MQTT Server plus client bridge
//!
//! This function
//!    1. Initializes network driver and connects to the default AP
//!    2. Initializes the mqtt client ans server libraries and set up MQTT
//!       with the remote broker.
//!    3. handles the callback signals
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************
void * MqttClient(void *pvParameters)
{
    dbgOutputLoc(DLOC_TASK_ENTER);

    struct eventMessage queueElemRecv;
    long lRetVal = -1;

    /*Initializing Client and Subscribing to the Broker.                     */
    if(getApConnectionState() >= 0)
    {
        lRetVal = MqttClient_start();
        if(lRetVal == -1)
        {
            UART_PRINT("MQTT Client lib initialization failed\n\r");
            pthread_exit(0);
            return(NULL);
        }
    }

    dbgOutputLoc(DLOC_BEFORE_WHILE);

    while(1){

        dbgOutputLoc(DLOC_BEFORE_QUEUE);

        if(readFromEventQueue(&queueElemRecv)){

            dbgOutputLoc(DLOC_AFTER_QUEUE);

            switch(queueElemRecv.event)
            {
            //On-board client disconnected from remote broker, only
            //local MQTT network will work
            case LOCAL_CLIENT_DISCONNECTION:
                UART_PRINT("\n\rOn-board Client Disconnected\n\r\r\n");
                updateUiConnFlag(0);
                break;

            case THREAD_TERMINATE_REQ:
                updateUiConnFlag(0);
                pthread_exit(0);
                return(NULL);

            // if get unknown message, terminate
            default:
                UART_PRINT("Received unknown message type in event queue");
                dbgFail();
                break;
            }
        }
    }
}

//*****************************************************************************
//
//! This function connect the MQTT device to an AP with the SSID which was
//! configured in SSID_NAME definition which can be found in Network_if.h file,
//! if the device can't connect to to this AP a request from the user for other
//! SSID will appear.
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************
int32_t Mqtt_IF_Connect()
{
    int32_t lRetVal;
    char SSID_Remote_Name[32];
    int8_t Str_Length;

    memset(SSID_Remote_Name, '\0', sizeof(SSID_Remote_Name));
    Str_Length = strlen(SSID_NAME);

    if(Str_Length)
    {
        /*Copy the Default SSID to the local variable                        */
        strncpy(SSID_Remote_Name, SSID_NAME, Str_Length);
    }

    /*Reset The state of the machine                                         */
    Network_IF_ResetMCUStateMachine();

    /*Start the driver                                                       */
    lRetVal = Network_IF_InitDriver(ROLE_STA);
    if(lRetVal < 0)
    {
        UART_PRINT("Failed to start SimpleLink Device\n\r", lRetVal);
        return(-1);
    }

    /*Initialize AP security params                                          */
    SlWlanSecParams_t SecurityParams = { 0 };
    SecurityParams.Key = (signed char *) SECURITY_KEY;
    SecurityParams.KeyLen = strlen(SECURITY_KEY);
    SecurityParams.Type = SECURITY_TYPE;

    /*Connect to the Access Point                                            */
    lRetVal = Network_IF_ConnectAP(SSID_Remote_Name, SecurityParams);
    if(lRetVal < 0)
    {
        UART_PRINT("Connection to an AP failed\n\r");
        return(-1);
    }

    sleep(1);

    return(0);
}

//*****************************************************************************
//!
//! MQTT Start - Initialize and create all the items required to run the MQTT
//! protocol
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************
void Mqtt_start()
{
    int32_t threadArg = 100;

    // initialize queue
    if(!createEventMsgQueue()){
        UART_PRINT("Error creating queue.\n\r");
        dbgFail();
    }

    if(xTaskCreate( MqttClient, "mqttclient",configPOSIX_STACK_SIZE, (void *) &threadArg,2, NULL) != pdPASS){
        uint32_t initState = getInitState();
        initState &= ~MQTT_INIT_STATE;
        updateInitState(initState);

        UART_PRINT("MQTT thread create fail\n\r");
        return;
    }

    uint32_t initState = getInitState();
    initState &= ~MQTT_INIT_STATE;
    updateInitState(initState);

}

//*****************************************************************************
//!
//! MQTT Stop - Close the client instance and free all the items required to
//! run the MQTT protocol
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************

void Mqtt_Stop()
{
    struct eventMessage queueElement;
    struct eventMessage queueElemRecv;

    if(getApConnectionState() >= 0)
    {
        Mqtt_ClientStop(1);
    }

    queueElement.event = THREAD_TERMINATE_REQ;
    queueElement.msgPtr = NULL;

    /*write message indicating publish message                               */
    if(MQTT_SendMsgToQueue(&queueElement))
    {
        UART_PRINT(
            "\n\n\rQueue is full, throw first msg and send the new one\n\n\r");
        if(readFromEventQueue(&queueElemRecv)){
            MQTT_SendMsgToQueue(&queueElement);
        }else{
            UART_PRINT("\n\n\rError throwing first msg in queue.\n\n\r");
            dbgFail();
        }
    }

    sleep(2);

    sl_Stop(SL_STOP_TIMEOUT);
    UART_PRINT("\n\r Client Stop completed\r\n");

}

int32_t MqttClient_start()
{
    int32_t lRetVal = -1;
    int32_t iCount = 0;

    int32_t threadArg = 100;

    MQTTClient_ConnParams Mqtt_ClientCtx =
    {
        MQTTCLIENT_NETCONN_URL,
        SERVER_ADDRESS,
        PORT_NUMBER, 0, 0, 0,
        NULL
    };

    char ClientId[CLIENT_ID_LEN] = getClientId();

    MQTTClient_Params MqttClientExmple_params;
    MqttClientExmple_params.clientId = ClientId;
    MqttClientExmple_params.connParams = &Mqtt_ClientCtx;
    MqttClientExmple_params.mqttMode31 = MQTT_3_1;
    MqttClientExmple_params.blockingSend = true;

    uint32_t initState = getInitState();
    initState |= CLIENT_INIT_STATE;
    updateInitState(initState);


    /*Initialize MQTT client lib                                             */
    gMqttClient = MQTTClient_create(MqttClientCallback,
                                    &MqttClientExmple_params);
    if(gMqttClient == NULL)
    {
        /*lib initialization failed                                          */
        uint32_t initState = getInitState();
        initState &= ~CLIENT_INIT_STATE;
        updateInitState(initState);
        return(-1);
    }

    if(xTaskCreate( MqttClientThread, "mqttclientthread",configPOSIX_STACK_SIZE, (void *) &threadArg,2, NULL) != pdPASS){
        UART_PRINT("Client Thread Create Failed failed\n\r");
        uint32_t initState = getInitState();
        initState &= ~CLIENT_INIT_STATE;
        updateInitState(initState);
        return(-1);
    }



    /*setting will parameters                                                */
    MQTTClient_Will will_param =
    {
        WILL_TOPIC,
        WILL_MSG,
        WILL_QOS,
        WILL_RETAIN
    };

    MQTTClient_set(gMqttClient, MQTTClient_WILL_PARAM, &will_param,
                   sizeof(will_param));


    /*Initiate MQTT Connect                                                  */
    if(getApConnectionState() >= 0)
    {
#if CLEAN_SESSION == false
        bool clean = CLEAN_SESSION;
        MQTTClient_set(gMqttClient, MQTTClient_CLEAN_CONNECT, (void *)&clean,
                       sizeof(bool));
#endif
        /*The return code of MQTTClient_connect is the ConnACK value that
           returns from the server */
        lRetVal = MQTTClient_connect(gMqttClient);

        /*negative lRetVal means error,
           0 means connection successful without session stored by the server,
           greater than 0 means successful connection with session stored by
           the server */
        if(0 > lRetVal)
        {
            /*lib initialization failed                                      */
            UART_PRINT("Connection to broker failed, Error code: %d\n\r",
                       lRetVal);

            updateUiConnFlag(0);
        }
        else
        {
            updateUiConnFlag(1);
        }
        /*Subscribe to topics when session is not stored by the server       */
        if((getUiConnFlag() == 1) && (0 == lRetVal))
        {
            uint8_t subIndex;
            MQTTClient_SubscribeParams subscriptionInfo[
                SUBSCRIPTION_TOPIC_COUNT];

            for(subIndex = 0; subIndex < SUBSCRIPTION_TOPIC_COUNT; subIndex++)
            {
                subscriptionInfo[subIndex].topic = topic[subIndex];
                subscriptionInfo[subIndex].qos = qos[subIndex];
            }

            if(MQTTClient_subscribe(gMqttClient, subscriptionInfo,
                                    SUBSCRIPTION_TOPIC_COUNT) < 0)
            {
                UART_PRINT("\n\r Subscription Error \n\r");
                MQTTClient_disconnect(gMqttClient);
                updateUiConnFlag(0);
            }
            else
            {
                for(iCount = 0; iCount < SUBSCRIPTION_TOPIC_COUNT; iCount++)
                {
                    UART_PRINT("Client subscribed on %s\n\r,", topic[iCount]);
                }
            }
        }
    }

    initState = getInitState();
    initState &= ~CLIENT_INIT_STATE;
    updateInitState(initState);

    return(0);
}

//*****************************************************************************
//!
//! MQTT Client stop - Unsubscribe from the subscription topics and exit the
//! MQTT client lib.
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************

void Mqtt_ClientStop(uint8_t disconnect)
{
    uint32_t iCount;

    MQTTClient_UnsubscribeParams subscriptionInfo[SUBSCRIPTION_TOPIC_COUNT];

    for(iCount = 0; iCount < SUBSCRIPTION_TOPIC_COUNT; iCount++)
    {
        subscriptionInfo[iCount].topic = topic[iCount];
    }

    MQTTClient_unsubscribe(gMqttClient, subscriptionInfo,
                           SUBSCRIPTION_TOPIC_COUNT);
    for(iCount = 0; iCount < SUBSCRIPTION_TOPIC_COUNT; iCount++)
    {
        UART_PRINT("Unsubscribed from the topic %s\r\n", topic[iCount]);
    }
    updateUiConnFlag(0);

    /*exiting the Client library                                             */
    MQTTClient_delete(gMqttClient);

}

//*****************************************************************************
//!
//! Set the ClientId with its own mac address
//! This routine converts the mac address which is given
//! by an integer type variable in hexadecimal base to ASCII
//! representation, and copies it into the ClientId parameter.
//!
//! \param  macAddress  -   Points to string Hex.
//!
//! \return void.
//!
//*****************************************************************************
int32_t SetClientIdNamefromMacAddress()
{
    int32_t ret = 0;
    uint8_t Client_Mac_Name[2];
    uint8_t Index;
    uint16_t macAddressLen = SL_MAC_ADDR_LEN;
    uint8_t macAddress[SL_MAC_ADDR_LEN];

    /*Get the device Mac address */
    ret = sl_NetCfgGet(SL_NETCFG_MAC_ADDRESS_GET, 0, &macAddressLen,
                       &macAddress[0]);

    /*When ClientID isn't set, use the mac address as ClientID               */
    char ClientId[CLIENT_ID_LEN] = getClientId();

    if(ClientId[0] == '\0')
    {
        /*6 bytes is the length of the mac address                           */
        for(Index = 0; Index < SL_MAC_ADDR_LEN; Index++)
        {
            /*Each mac address byte contains two hexadecimal characters      */
            /*Copy the 4 MSB - the most significant character                */
            Client_Mac_Name[0] = (macAddress[Index] >> 4) & 0xf;
            /*Copy the 4 LSB - the least significant character               */
            Client_Mac_Name[1] = macAddress[Index] & 0xf;

            if(Client_Mac_Name[0] > 9)
            {
                /*Converts and copies from number that is greater than 9 in  */
                /*hexadecimal representation (a to f) into ascii character   */
                ClientId[2 * Index] = Client_Mac_Name[0] + 'a' - 10;
            }
            else
            {
                /*Converts and copies from number 0 - 9 in hexadecimal       */
                /*representation into ascii character                        */
                ClientId[2 * Index] = Client_Mac_Name[0] + '0';
            }
            if(Client_Mac_Name[1] > 9)
            {
                /*Converts and copies from number that is greater than 9 in  */
                /*hexadecimal representation (a to f) into ascii character   */
                ClientId[2 * Index + 1] = Client_Mac_Name[1] + 'a' - 10;
            }
            else
            {
                /*Converts and copies from number 0 - 9 in hexadecimal       */
                /*representation into ascii character                        */
                ClientId[2 * Index + 1] = Client_Mac_Name[1] + '0';
            }
        }
    }

    return(ret);
}

void mainThread(void * args)
{
    // initialize GPIO for debugging
    initGPIO();
    dbgOutputLoc(DLOC_TASK_ENTER);

    pthread_t spawn_thread = (pthread_t) NULL;
    pthread_attr_t pAttrs_spawn;
    struct sched_param priParam;
    int32_t retc = 0;

    /*Initialize SlNetSock layer with CC31xx/CC32xx interface */
    SlNetIf_init(0);
    SlNetIf_add(SLNETIF_ID_1, "CC32xx",
                (const SlNetIf_Config_t *)&SlNetIfConfigWifi,
                SLNET_IF_WIFI_PRIO);
    SlNetSock_init(0);
    SlNetUtil_init(0);
    SPI_init();

    // open UART
    if(!InitTerm()){
        dbgFail();
    }

    if(!initUart()){
        dbgFail();
    }

    //Create the sl_Task as posix thread since uses mutex
    pthread_attr_init(&pAttrs_spawn);
    priParam.sched_priority = SPAWN_TASK_PRIORITY;
    retc = pthread_attr_setschedparam(&pAttrs_spawn, &priParam);
    retc |= pthread_attr_setstacksize(&pAttrs_spawn, TASKSTACKSIZE);
    retc |= pthread_attr_setdetachstate
                                    (&pAttrs_spawn, PTHREAD_CREATE_DETACHED);
    retc = pthread_create(&spawn_thread, &pAttrs_spawn, sl_Task, NULL);
    if(retc != 0)
    {
        UART_PRINT("could not create simplelink task\n\r");
        dbgFail();
    }
    retc = sl_Start(0, 0, 0);
    if(retc < 0)
    {
        UART_PRINT("\n sl_Start failed\n");
        dbgFail();
    }
    retc |= SetClientIdNamefromMacAddress();
    retc = sl_Stop(SL_STOP_TIMEOUT);
    if(retc < 0)
    {
        UART_PRINT("\n sl_Stop failed\n");
        dbgFail();
    }
    if(retc < 0)
    {
        UART_PRINT("mqtt_client - Unable to retrieve device information \n");
        dbgFail();
    }

    // initialize variables
    initializeState();
    topic[0] = SUBSCRIPTION_TOPIC0;

    //Connect to AP
    int32_t connState = Mqtt_IF_Connect();
    updateConnectionState(connState);

    uint32_t initState = getInitState();
    initState |= MQTT_INIT_STATE;
    updateInitState(initState);

    //Run MQTT Main Thread (it will open the Client and Server)
    Mqtt_start();


    if (!createPSMsgQueue() || !pTimerFunct() || !sTimerFunct()) {
        UART_PRINT("Failed to start timer or queue.\r\n");
        dbgFail();
    }

    // start new threads
    if(!startMainMQTTTask()){
        UART_PRINT("Failed to start mainMQTT task.\r\n");
        dbgFail();
    }

    dbgOutputLoc(DLOC_BEFORE_WHILE);
    while(1)
    {
        if(getResetApplication() == true)
        {
            UART_PRINT("TO Complete - Closing all threads and resources\r\n");

            /*Stop the MQTT Process                                              */
            Mqtt_Stop();
        }

    }
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
