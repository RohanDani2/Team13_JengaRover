#include <debug.h>

// initalize GPIO
void initGPIO(){
    GPIO_init();
    GPIO_setConfig(CONFIG_GPIO_PIN_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(CONFIG_GPIO_PIN_1, GPIO_OFF);
    GPIO_setConfig(CONFIG_GPIO_PIN_2, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(CONFIG_GPIO_PIN_2, GPIO_OFF);
    GPIO_setConfig(CONFIG_GPIO_PIN_3, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(CONFIG_GPIO_PIN_3, GPIO_OFF);
    GPIO_setConfig(CONFIG_GPIO_PIN_4, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(CONFIG_GPIO_PIN_4, GPIO_OFF);
    GPIO_setConfig(CONFIG_GPIO_PIN_5, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(CONFIG_GPIO_PIN_5, GPIO_OFF);
    GPIO_setConfig(CONFIG_GPIO_PIN_6, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(CONFIG_GPIO_PIN_6, GPIO_OFF);
    GPIO_setConfig(CONFIG_GPIO_PIN_7, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(CONFIG_GPIO_PIN_7, GPIO_OFF);
}

// output an error code and suspend task
void dbgFail(){
    dbgOutputLoc(DEBUG_ERROR);
    vTaskSuspend(NULL);
}

// write to GPIO pins
void dbgOutputLoc(unsigned int outLoc){
    if(outLoc > 127){
        dbgFail();
    }

    if (outLoc & (1 << 1))
        GPIO_write(CONFIG_GPIO_PIN_1, GPIO_ON);
    else
        GPIO_write(CONFIG_GPIO_PIN_1, GPIO_OFF);
    if (outLoc & (1 << 2))
        GPIO_write(CONFIG_GPIO_PIN_2, GPIO_ON);
    else
        GPIO_write(CONFIG_GPIO_PIN_2, GPIO_OFF);
    if (outLoc & (1 << 3))
        GPIO_write(CONFIG_GPIO_PIN_3, GPIO_ON);
    else
        GPIO_write(CONFIG_GPIO_PIN_3, GPIO_OFF);
    if (outLoc & (1 << 4))
        GPIO_write(CONFIG_GPIO_PIN_4, GPIO_ON);
    else
        GPIO_write(CONFIG_GPIO_PIN_4, GPIO_OFF);
    if (outLoc & (1 << 5))
        GPIO_write(CONFIG_GPIO_PIN_5, GPIO_ON);
    else
        GPIO_write(CONFIG_GPIO_PIN_5, GPIO_OFF);
    if (outLoc & (1 << 6))
        GPIO_write(CONFIG_GPIO_PIN_6, GPIO_ON);
    else
        GPIO_write(CONFIG_GPIO_PIN_6, GPIO_OFF);

    GPIO_toggle(CONFIG_GPIO_PIN_7);
}


