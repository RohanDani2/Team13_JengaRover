#ifndef PARSEJSON_H_
#define PARSEJSON_H_

// need to declare before including jsmn
#define JSMN_STATIC

#include <jsmn.h>
#include <string.h>
#include <stdint.h>
#include <uart_term.h>
#include <pubSubQueue.h>

#define MAX_TOKENS 128

#define MAX_TOK_LENGTH 257

#define STATE_MSG_TOKENS 6

struct recvMsg{
    int32_t state;
    int32_t seq;
    int32_t checksum;
};

/* check if a token's string is equal to a test string (provided in jsmn repo)
 * return 1 on true, 0 on false
 */
int jsoneq(const char *json, jsmntok_t *tok, const char *s);

/* add string's value to checksum
 * return the value to add to checksum
 */
int addStringChecksum(unsigned char *string, size_t length);

/* generate checksum of sensor message
 * return the checksum
*/
int generateSensorChecksum(char * sensor, int32_t seq);

/* generate checksum of statistics message
 * return the checksum
*/
int generateStatsChecksum(int32_t publish_attempt, int32_t subscribe_received, int32_t subscribe_shouldReceived);

/* attempt to parse JSON string for state message, verify checksum in process
 * return 1 on succesful parse, 0 on failed parse
 */
int parseStateJSON(char* s, struct recvMsg *m);

// convert msg structs to json
int32_t jsonifySensor(char* publish_data, int32_t buf_size, char * data_buf, int32_t sequence);
int32_t jsonifyStats(char* publish_data, int32_t buf_size, int32_t publish_attempt, int32_t subscribe_received, int32_t subscribe_shouldReceived);

#endif /* PARSEJSON_H_ */
